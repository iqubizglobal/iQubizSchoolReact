
iQubiz School App - Components split into one folder per component (no tests).
Structure:
src/components/
  AdminSetup/index.jsx
  RoleEditor/index.jsx
  UserEditor/index.jsx
  Attendance/index.jsx
  Homework/index.jsx
  Dashboard/index.jsx
  Icons/index.jsx

Storage helpers: src/storage.js
Main app: src/App.jsx
